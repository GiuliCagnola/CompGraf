#include "testsCalcularPesos.hpp"
PruebaCalcularPesos probar_calcular_pesos;
