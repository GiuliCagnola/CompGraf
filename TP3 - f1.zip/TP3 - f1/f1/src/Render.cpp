#include <glm/ext.hpp>
#include "Render.hpp"
#include "Callbacks.hpp"

extern bool wireframe, play, top_view, antialiasing;

// matrices que definen la camara
glm::mat4 projection_matrix, view_matrix;

// funci�n para renderizar cada "parte" del auto
void renderPart(const Car &car, const std::vector<Model> &v_models, const glm::mat4 &matrix, Shader &shader) {
	// select a shader
	for(const Model &model : v_models) {
		shader.use();
		
		// matrixes
		if (play) {
			
			glm::mat4 Mcar = glm::mat4(cos(car.ang), 0.0f, sin(car.ang), 0.0f,
										0.0f, 1.0f, 0.0f, 0.0f,
										-sin(car.ang), 0.0f, cos(car.ang), 0.0f,
										car.x, 0.0f, car.y, 1.0f);
			
			
			shader.setMatrixes(Mcar*matrix,view_matrix,projection_matrix);
		} else {
			glm::mat4 model_matrix = glm::rotate(glm::mat4(1.f),view_angle,glm::vec3{1.f,0.f,0.f}) *
						             glm::rotate(glm::mat4(1.f),model_angle,glm::vec3{0.f,1.f,0.f}) *
			                         matrix;
			shader.setMatrixes(model_matrix,view_matrix,projection_matrix);
		}
		
		// setup light and material
		shader.setLight(glm::vec4{20.f,40.f,20.f,0.f}, glm::vec3{1.f,1.f,1.f}, 0.35f);
		shader.setMaterial(model.material);
		
		// send geometry
		shader.setBuffers(model.buffers);
		glPolygonMode(GL_FRONT_AND_BACK,(wireframe and (not play))?GL_LINE:GL_FILL);
		model.buffers.draw();
	}
}

// funci�n que actualiza las matrices que definen la c�mara
void setViewAndProjectionMatrixes(const Car &car) {
	projection_matrix = glm::perspective( glm::radians(view_fov), float(win_width)/float(win_height), 0.1f, 100.f );
	if (play) {
		if (top_view) {
			glm::vec3 pos_auto = {car.x, 0.f, car.y};
			///para que la c�mara siga al auto, esta debe girar en el mismo �ngulo en x y en y
			view_matrix = glm::lookAt( pos_auto+glm::vec3{0.f,30.f,0.f}, pos_auto, glm::vec3{cos(car.ang),0.f, sin(car.ang)} );

			
		} else {
			/// @todo: definir view_matrix de modo que la camara persiga al auto desde "atras"
			glm::vec3 pos_auto = {car.x, 0.f, car.y};
			///la c�mara depende del �ngulo del auto
			view_matrix = glm::lookAt(pos_auto+glm::vec3{-5*cos(car.ang),2.f,-5*sin(car.ang)}, pos_auto, glm::vec3{0.f,1.f,0.f});
		}

	} else {
		view_matrix = glm::lookAt( glm::vec3{0.f,0.f,3.f}, view_target, glm::vec3{0.f,1.f,0.f} );
	}
}

// funci�n que rendiriza todo el auto, parte por parte
void renderCar(const Car &car, const std::vector<Part> &parts, Shader &shader) {
	const Part &axis = parts[0], &body = parts[1], &wheel = parts[2],
	           &fwing = parts[3], &rwing = parts[4], &helmet = parts[antialiasing?5:6];
	
	
	///elem(1,1) modifica el eje x (ancho)
	///elem(2,2) modifica el eje y (alto)
	///elem(3,3) modifica el eje z (profundidad)
	///elem(4,1) desplaza sobre el eje x (derecha-izquierda)
	///elem(4,2) desplaza sobre el eje y (arriba-abajo)
	///elem(4,3) desplaza sobre el eje z (adelante-atr�s)
	///elem(4,4) escala todo el objeto inversamente al valor (agranda-achica)
	
	
	if (body.show or play) {
		glm::mat4 Mbody = glm::mat4(1.0f, 0.0f, 0.0f, 0.0f,
									0.0f, 1.0f, 0.0f, 0.0f,
									0.0f, 0.0f, 1.0f, 0.0f,
									0.0f, 0.2f, 0.0f, 1.0f);
		renderPart(car,body.models, Mbody,shader);
	}
	
	if (wheel.show or play) {
		
		///Rotaci�n angular de las ruedas
		glm::mat4 giro1 = glm::mat4(cos(car.rang1), 0.0f, sin
									(car.rang1), 0.0f,
									0.0f, 1.0f, 0.0f, 0.0f,
									-sin(car.rang1), 0.0f, cos(car.rang1), 0.0f,
									 0.0f, 0.0f, 0.0f, 1.0f );
		
		
		glm::mat4 giro2 = glm::mat4(cos(car.rang1), 0.0f, -sin(car.rang1), 0.0f,
									0.0f, 1.0f, 0.0f, 0.0f,
									sin(car.rang1), 0.0f, cos(car.rang1), 0.0f,
									0.0f, 0.0f, 0.0f, 1.0f );
	
		///Rotaci�n sobre el eje para rodar
		glm::mat4 rodar = glm::mat4(cos(car.rang2), -sin(car.rang2), 0.0f, 0.0f,
									sin(car.rang2), cos(car.rang2), 0.0f, 0.0f,
									0.0f, 0.0f, 1.0f, 0.0f,
									0.0f, 0.0f, 0.0f, 1.0f );
	
		
		///Rueda 1
		glm::mat4 Mwheel_1 = glm::mat4(0.15f, 0.0f, 0.0f, 0.0f,
									   0.0f, 0.15f, 0.0f, 0.0f,
									   0.0f, 0.0f, 0.15f, 0.0f,
									   0.5f, 0.15f, -0.3f, 1.0f);
		
		renderPart(car,wheel.models, Mwheel_1*rodar*giro1,shader); 
		
		///Rueda 2
		glm::mat4 Mwheel_2 = glm::mat4(0.15f, 0.0f, 0.0f, 0.0f,
									   0.0f, 0.15f, 0.0f, 0.0f,
									   0.0f, 0.0f, -0.15f, 0.0f,
									   0.5f, 0.15f, 0.3f, 1.0f);
		
		renderPart(car,wheel.models, Mwheel_2*rodar*giro2,shader);
		
		///Rueda 3
		glm::mat4 Mwheel_3 = glm::mat4(0.15f, 0.0f, 0.0f, 0.0f,
									   0.0f, 0.15f, 0.0f, 0.0f,
									   0.0f, 0.0f, 0.15f, 0.0f,
									   -0.9f, 0.2f, -0.3f, 1.0f);
		
		renderPart(car,wheel.models, Mwheel_3*rodar,shader);
		
		///Rueda 4
		glm::mat4 Mwheel_4 = glm::mat4(0.15f, 0.0f, 0.0f, 0.0f,
									   0.0f, 0.15f, 0.0f, 0.0f,
									   0.0f, 0.0f, -0.15f, 0.0f,
									   -0.9f, 0.2f, 0.3f, 1.0f);
		
		renderPart(car,wheel.models, Mwheel_4*rodar,shader);
	
	}
	
	if (fwing.show or play) {
		glm::mat4 Mfwing = glm::mat4(0.0f, 0.0f, 0.5f, 0.0f,
									 0.0f, 0.5f, 0.0f, 0.0f,
									 -0.5f, 0.0f, 0.0f, 0.0f,
									 1.0f, 0.16f, 0.0f, 1.0f);
		
		renderPart(car,fwing.models, Mfwing,shader);
	}
	
	if (rwing.show or play) {
		float scl = 0.30f;
		glm::mat4 Mrwing = glm::mat4(0.0f, 0.0f, 0.5f, 0.0f,
									 0.0f, 0.5f, 0.0f, 0.0f,
									 -0.5f, 0.0f, 0.0f, 0.0f,
									 -0.8f, 0.5f, 0.0f, 1.0f);
		renderPart(car,rwing.models, Mrwing, shader);
	}
	
	if (helmet.show or play) {
		glm::mat4 Mhelmet = glm::mat4(0.0f, 0.0f, 0.2f, 0.0f,
									  0.0f, 0.2f, 0.0f, 0.0f,
									  -0.2f, 0.0f, 0.0f, 0.0f,
									  0.0f, 0.4f, 0.0f, 1.0f);
		

		renderPart(car,helmet.models, Mhelmet, shader);
	}
	
	if (axis.show and (not play)) renderPart(car,axis.models,glm::mat4(1.f),shader);
}

// funci�n que renderiza la pista
void renderTrack() {
	static Model track = Model::loadSingle("models/track",Model::fDontFit);
	static Shader shader("shaders/texture");
	shader.use();
	shader.setMatrixes(glm::mat4(1.f),view_matrix,projection_matrix);
	shader.setMaterial(track.material);
	shader.setBuffers(track.buffers);
	track.texture.bind();
	static float aniso = -1.0f;
	if (aniso<0) glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &aniso);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, aniso);
	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	track.buffers.draw();
}

void renderShadow(const Car &car, const std::vector<Part> &parts) {
	static Shader shader_shadow("shaders/shadow");
	glEnable(GL_STENCIL_TEST); glClear(GL_STENCIL_BUFFER_BIT);
	glStencilFunc(GL_EQUAL,0,~0); glStencilOp(GL_KEEP,GL_KEEP,GL_INCR);
	renderCar(car,parts,shader_shadow);
	glDisable(GL_STENCIL_TEST);
}
